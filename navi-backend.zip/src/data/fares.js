// Statische Referenz-Fahrpreise für den VBB-Tarif (Region Berlin, Regeltarif).
// WICHTIG: Das ist keine Live-Preisabfrage (die HAFAS-API liefert keine Preise) -
// das sind von Hand gepflegte, öffentlich bekannte Tarifdaten. Müssen bei
// Tarifänderungen manuell aktualisiert werden. Immer mit "ohne Gewähr" anzeigen!

const FARES = {
  stand: '2026-01-01',
  quelle: 'https://www.vbb.de/tickets/',
  hinweis: 'Alle Preise ohne Gewähr. Tarife können sich ändern - verbindlich sind die Angaben von VBB/BVG.',
  gruppen: [
    {
      titel: 'Einzelfahrten',
      tickets: [
        { name: 'Kurzstrecke', bereich: 'Berlin AB', preis: 2.80, hinweis: 'bis 3 Stationen S/U-Bahn oder 6 Haltestellen Bus/Tram' },
        { name: 'Einzelfahrschein', bereich: 'Berlin AB', preis: 4.00, hinweis: '120 Minuten, Umsteigen erlaubt' },
        { name: 'Einzelfahrschein', bereich: 'Berlin ABC', preis: 5.00, hinweis: 'inkl. Flughafen BER' },
        { name: '4-Fahrten-Karte', bereich: 'Kurzstrecke', preis: 7.80 },
        { name: '4-Fahrten-Karte', bereich: 'Berlin AB', preis: 12.40, hinweis: '3,10 € pro Fahrt' },
        { name: '4-Fahrten-Karte', bereich: 'Berlin ABC', preis: 16.80 },
      ],
    },
    {
      titel: 'Tageskarten',
      tickets: [
        { name: '24-Stunden-Karte', bereich: 'Berlin AB', preis: 11.20 },
        { name: '24-Stunden-Karte', bereich: 'Berlin ABC', preis: 12.90 },
        { name: '24-Stunden-Karte Kleingruppe', bereich: 'Berlin AB', preis: 35.30, hinweis: 'bis 5 Personen' },
        { name: '24-Stunden-Karte Kleingruppe', bereich: 'Berlin ABC', preis: 37.70, hinweis: 'bis 5 Personen' },
      ],
    },
    {
      titel: 'Zeitkarten',
      tickets: [
        { name: 'Deutschlandticket', bereich: 'bundesweit', preis: 63.00, hinweis: 'pro Monat, im Abo' },
        { name: 'Monatskarte (VBB-Umweltkarte)', bereich: 'Berlin AB', preis: 113.00, hinweis: 'ohne Abo' },
        { name: 'Monatskarte (VBB-Umweltkarte)', bereich: 'Berlin ABC', preis: 132.00, hinweis: 'ohne Abo' },
      ],
    },
  ],
  unternehmen: [
    { name: 'BVG', url: 'https://www.bvg.de/de/abos-und-tickets/alle-tickets', beschreibung: 'U-Bahn, Bus, Tram in Berlin' },
    { name: 'S-Bahn Berlin', url: 'https://sbahn.berlin/fahrkarten/', beschreibung: 'S-Bahn-Tickets & Infos' },
    { name: 'VBB', url: 'https://www.vbb.de/tickets/', beschreibung: 'Alle Tarife für Berlin & Brandenburg' },
    { name: 'DB Regio', url: 'https://www.bahn.de/angebot/regio', beschreibung: 'Regionalzüge (RE/RB)' },
  ],
};

module.exports = { FARES };
