// Schützt schreibende Endpunkte (POST/DELETE) mit einem einfachen API-Key.
// Die iOS App schickt den Key im Header "X-API-Key" mit.

function requireApiKey(req, res, next) {
  const providedKey = req.header('X-API-Key');
  const expectedKey = process.env.API_KEY;

  if (!expectedKey || expectedKey === 'changeme_generiere_einen_zufaelligen_key') {
    return res.status(500).json({
      error: 'Server ist nicht korrekt konfiguriert (API_KEY fehlt oder ist Standardwert).',
    });
  }

  if (!providedKey || providedKey !== expectedKey) {
    return res.status(401).json({ error: 'Ungültiger oder fehlender API-Key.' });
  }

  next();
}

module.exports = requireApiKey;
