// Sehr grobe Schätzung des VBB-Tarifbereichs (AB/ABC) und eines Richtpreises
// anhand der Luftlinien-Entfernung vom Berliner Zentrum. Das ist KEINE echte
// Tarifzonen-Berechnung (die echten Zonengrenzen folgen nicht sauberen Kreisen,
// sondern Verwaltungsgrenzen) - nur eine Näherung, damit der Nutzer eine grobe
// Preisvorstellung bekommt. Muss im Frontend IMMER klar als Schätzung/ohne
// Gewähr gekennzeichnet werden, siehe /fares für die Kontaktdaten der echten
// Tarifauskunft.
//
// estimateFareExact() versucht zuerst eine EXAKTE Bestimmung über die
// offiziellen VBB-Tarifzonen-Daten (siehe vbbFareZones.js) und fällt nur auf
// die Distanz-Schätzung zurück, wenn eine der beiden Stationen dort nicht
// bekannt ist (z.B. weil sie außerhalb von Berlins eigenem Stadttarif liegt).

const vbbFareZones = require('./vbbFareZones');
const { FARES } = require('../data/fares');

const BERLIN_CENTER = { lat: 52.5200, lon: 13.4050 };
const AB_RADIUS_KM = 20;
const ABC_RADIUS_KM = 40;

// Preise aus der ohnehin gepflegten Fahrpreistabelle ziehen, statt sie hier
// ein zweites Mal fest zu verdrahten (Konsistenz bei Preisänderungen).
function findPreis(name, bereich) {
  for (const gruppe of FARES.gruppen) {
    const treffer = gruppe.tickets.find((t) => t.name === name && t.bereich === bereich);
    if (treffer) return treffer.preis;
  }
  return null;
}

function toRad(deg) {
  return (deg * Math.PI) / 180;
}

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function estimateFare(originLat, originLon, destLat, destLon) {
  if ([originLat, originLon, destLat, destLon].some((v) => v == null || Number.isNaN(v))) {
    return null;
  }

  const dOrigin = haversineKm(originLat, originLon, BERLIN_CENTER.lat, BERLIN_CENTER.lon);
  const dDest = haversineKm(destLat, destLon, BERLIN_CENTER.lat, BERLIN_CENTER.lon);
  const maxDist = Math.max(dOrigin, dDest);

  if (maxDist <= AB_RADIUS_KM) {
    return { zone: 'AB', price: findPreis('Einzelfahrschein', 'Berlin AB') ?? 4.0, exact: false };
  }
  if (maxDist <= ABC_RADIUS_KM) {
    return { zone: 'ABC', price: findPreis('Einzelfahrschein', 'Berlin ABC') ?? 5.0, exact: false };
  }
  return { zone: null, price: null, exact: false };
}

/**
 * Versucht zuerst die exakte Berlin-Tarifzone über die offiziellen VBB-Daten
 * zu bestimmen (anhand der Stationsnamen). Braucht beide Zonen-Buchstaben
 * (Start + Ziel) aus der offiziellen Zuordnung - nur wenn BEIDE bekannt sind,
 * gilt das Ergebnis als "exact". Sonst Rückfall auf die Distanz-Schätzung.
 */
function estimateFareExact(originName, destinationName, originLat, originLon, destLat, destLon) {
  const originZone = vbbFareZones.getBerlinZone(originName);
  const destZone = vbbFareZones.getBerlinZone(destinationName);

  if (originZone && destZone) {
    const needsC = originZone === 'C' || destZone === 'C';
    const zone = needsC ? 'ABC' : 'AB';
    const price = needsC
      ? findPreis('Einzelfahrschein', 'Berlin ABC')
      : findPreis('Einzelfahrschein', 'Berlin AB');
    if (price != null) return { zone, price, exact: true };
  }

  return estimateFare(originLat, originLon, destLat, destLon);
}

module.exports = { estimateFare, estimateFareExact };
