// Client für unsere selbst gehostete OpenTripPlanner-2-Instanz (VBB-Region).
// Ersetzt die HAFAS-basierte Routenplanung durch eine komplett offene,
// selbst gehostete Lösung auf Basis von VBB-GTFS + OpenStreetMap.

const OTP_BASE_URL = process.env.OTP_BASE_URL || 'http://localhost:8080/otp/gtfs/v1';
console.log(`[otpClient] Verwende OTP-Server: ${OTP_BASE_URL}`);

// Für "dateTime" wird bewusst kein GraphQL-Variablentyp verwendet (der genaue
// Name des Input-Typs ist in der öffentlichen Doku nicht dokumentiert) -
// stattdessen bauen wir dieses eine Feld direkt als Inline-Literal in den
// Query-String, exakt wie im offiziellen Tutorial gezeigt. Alle anderen Werte
// (Zahlen) laufen ganz normal als typisierte Variablen.
function buildPlanQuery(dateTimeIso, arriveBy) {
  const dateTimeField = arriveBy
    ? `latestArrival: "${dateTimeIso}"`
    : `earliestDeparture: "${dateTimeIso}"`;

  return `
    query Plan($fromLat: CoordinateValue!, $fromLon: CoordinateValue!, $toLat: CoordinateValue!, $toLon: CoordinateValue!, $numItineraries: Int) {
      planConnection(
        origin: { location: { coordinate: { latitude: $fromLat, longitude: $fromLon } } }
        destination: { location: { coordinate: { latitude: $toLat, longitude: $toLon } } }
        dateTime: { ${dateTimeField} }
        first: $numItineraries
      ) {
        edges {
          node {
            start
            end
            legs {
              mode
              distance
              from {
                name lat lon
                departure { scheduledTime estimated { time delay } }
              }
              to {
                name lat lon
                arrival { scheduledTime estimated { time delay } }
              }
              route { shortName longName }
              legGeometry { points }
            }
          }
        }
      }
    }
  `;
}

async function planJourney({ fromLat, fromLon, toLat, toLon, dateTime, arriveBy, numItineraries = 5 }) {
  const dateTimeIso = dateTime ? new Date(dateTime).toISOString() : new Date().toISOString();

  const variables = { fromLat, fromLon, toLat, toLon, numItineraries };

  let response;
  try {
    response = await fetch(OTP_BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: buildPlanQuery(dateTimeIso, !!arriveBy), variables }),
    });
  } catch (err) {
    const wrapped = new Error('OTP-Server nicht erreichbar: ' + err.message);
    wrapped.code = 'OTP_UNREACHABLE';
    throw wrapped;
  }

  let body;
  try {
    body = await response.json();
  } catch (err) {
    const wrapped = new Error(
      `OTP-Server antwortete mit ungültigem JSON (Status ${response.status}). ` +
        'Prüfe, ob OTP_BASE_URL korrekt auf ".../otp/gtfs/v1" zeigt.',
    );
    wrapped.code = 'OTP_GRAPHQL_ERROR';
    throw wrapped;
  }

  if (body.errors && body.errors.length > 0) {
    const wrapped = new Error('OTP-GraphQL-Fehler: ' + body.errors.map((e) => e.message).join('; '));
    wrapped.code = 'OTP_GRAPHQL_ERROR';
    throw wrapped;
  }

  const edges = body.data && body.data.planConnection ? body.data.planConnection.edges : [];
  return edges.map((e) => e.node);
}

module.exports = { planJourney };
