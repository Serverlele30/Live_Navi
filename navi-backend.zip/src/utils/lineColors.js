// Liefert Vordergrund-/Hintergrundfarbe für eine Linie, passend zum echten
// BVG/VBB-Corporate-Design (z.B. U4 = gelb mit schwarzer Schrift, wie auf den
// echten Wagen/Anzeigen). Nutzt "vbb-line-colors" (gleicher Autor wie hafas-client)
// als Datenquelle. Für Linien ohne Eintrag (v.a. Bus-Einzellinien, Fernverkehr,
// Fähre - dafür gibt es laut VBB keine offiziellen Linienfarben, nur Produktfarben)
// wird eine sinnvolle Fallback-Farbe pro Verkehrsmittel verwendet.

const colors = require('vbb-line-colors');

const FALLBACKS = {
  suburban: { bg: '#006F35', fg: '#fff' }, // S-Bahn-Grün (Produktfarbe)
  subway: { bg: '#0074F3', fg: '#fff' }, // U-Bahn-Blau (Produktfarbe)
  tram: { bg: '#FF0000', fg: '#fff' }, // Tram-Rot (Produktfarbe)
  bus: { bg: '#9900FF', fg: '#fff' }, // Bus-Lila (Produktfarbe, keine Linienfarben bei Bus)
  ferry: { bg: '#33CCFF', fg: '#fff' }, // Fähre-Hellblau (Produktfarbe)
  express: { bg: '#EC0016', fg: '#fff' }, // DB-Rot für Fernverkehr (IC/ICE, kein VBB-Produkt)
  regional: { bg: '#5B6B7A', fg: '#fff' }, // neutrales Blaugrau als Fallback für unbekannte RE/RB
};

const DEFAULT = { bg: '#8E99A6', fg: '#fff' };

function normalize(name) {
  return name ? name.replace(/\s+/g, '').toUpperCase() : null;
}

function getLineColor(mode, lineName) {
  const key = normalize(lineName);
  const table = mode && colors[mode];

  if (table && key && table[key]) {
    return { bg: table[key].bg, fg: table[key].fg };
  }

  return (mode && FALLBACKS[mode]) || DEFAULT;
}

// Für Quellen ohne VBB-Produktfeld (z.B. OTP2/GTFS, das nur generische Modi wie
// "RAIL" liefert, egal ob S-Bahn oder Regionalbahn): sucht den Liniennamen direkt
// in allen bekannten Kategorien nach, statt das Produkt raten zu müssen.
function getLineColorByNameOnly(lineName) {
  const key = normalize(lineName);
  if (!key) return DEFAULT;

  for (const product of ['suburban', 'subway', 'tram', 'regional']) {
    const table = colors[product];
    if (table && table[key]) {
      return { bg: table[key].bg, fg: table[key].fg };
    }
  }

  // Fernverkehr (ICE/IC/EC/RJ/NJ) ist eindeutig am Präfix erkennbar und nie
  // mehrdeutig mit anderen Verkehrsmitteln, daher hier sicher als Sonderfall.
  if (/^(ICE|IC|EC|RJ|NJ)\b/i.test(lineName)) {
    return FALLBACKS.express;
  }

  return DEFAULT; // meist Bus-Linien, für die es keine offizielle Linienfarbe gibt
}

module.exports = { getLineColor, getLineColorByNameOnly };
