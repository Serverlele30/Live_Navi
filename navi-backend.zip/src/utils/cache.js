// Simpler In-Memory-Cache mit TTL (kein Redis o.ä. nötig für diese Größenordnung).
// Schützt die Upstream-APIs (VBB/DB-IRIS/OTP) vor doppelten Anfragen, wenn z.B.
// mehrere Geräte/Tabs kurz hintereinander dieselbe Abfahrtstafel laden.

const store = new Map();

/**
 * Führt fn() aus und cached das Ergebnis für ttlMs unter "key". Wiederholte
 * Aufrufe mit demselben Key innerhalb der TTL bekommen die gecachte Antwort,
 * ohne die eigentliche (teure) Funktion erneut aufzurufen.
 */
async function withCache(key, ttlMs, fn) {
  const now = Date.now();
  const entry = store.get(key);

  if (entry && entry.expiresAt > now) {
    return entry.value;
  }

  const value = await fn();
  store.set(key, { value, expiresAt: now + ttlMs });
  return value;
}

// Räumt abgelaufene Einträge regelmäßig auf, damit der Speicher nicht wächst
// (bei vielen unterschiedlichen Stationen/Routen könnten sonst viele einzelne
// Cache-Keys liegen bleiben).
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of store.entries()) {
    if (entry.expiresAt <= now) store.delete(key);
  }
}, 60_000).unref();

module.exports = { withCache };
