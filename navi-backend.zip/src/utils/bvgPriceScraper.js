// Holt aktuelle Ticketpreise direkt von der offiziellen BVG-Übersichtsseite
// und aktualisiert damit automatisch unsere statische Fahrpreistabelle
// (data/fares.js). Das ist Web-Scraping einer normalen, öffentlichen
// Marketing-Seite (keine interne/inoffizielle API) - deutlich unkritischer
// als das DB-Navigator-Grauzonen-Thema, das wir bei der Routenplanung bewusst
// vermieden haben. Trotzdem: Seiten-Redesigns können den Scraper brechen,
// daher IMMER mit Plausibilitäts-Check gegen offensichtlichen Unsinn.
//
// WICHTIG - Grenzen: Diese Übersichtsseite zeigt nur den günstigsten Preis
// pro Ticket ("Regeltarif ab X,XX €", i.d.R. Berlin AB). Die ABC-Preise
// stehen nur auf den einzelnen Ticket-Unterseiten und werden hier NICHT
// automatisch aktualisiert - die bleiben manuell gepflegt.

const { FARES } = require('../data/fares');

const BVG_URL = 'https://www.bvg.de/de/abos-und-tickets/alle-tickets';
const REFRESH_INTERVAL_MS = 24 * 60 * 60 * 1000; // täglich

// Realistische Preisspanne für VBB-Einzeltickets - alles außerhalb davon ist
// mit an Sicherheit grenzender Wahrscheinlichkeit ein Parsing-Fehler
// (z.B. weil BVG die Seite umgebaut hat) und wird NICHT übernommen.
const MIN_PLAUSIBLE_PRICE = 0.5;
const MAX_PLAUSIBLE_PRICE = 300;

// Mapping: Ticket-Name wie er auf der BVG-Seite steht -> unser fares.js-Eintrag
// (name + bereich müssen exakt zu data/fares.js passen).
const SCRAPE_TARGETS = [
  { pageName: 'Kurzstrecke', name: 'Kurzstrecke', bereich: 'Berlin AB' },
  { pageName: 'Einzelfahrschein', name: 'Einzelfahrschein', bereich: 'Berlin AB' },
  { pageName: '4-Fahrten-Karte Kurzstrecke', name: '4-Fahrten-Karte', bereich: 'Kurzstrecke' },
  { pageName: '4-Fahrten-Karte', name: '4-Fahrten-Karte', bereich: 'Berlin AB' },
  { pageName: '24-Stunden-Karte Kleingruppe', name: '24-Stunden-Karte Kleingruppe', bereich: 'Berlin AB' },
  { pageName: '24-Stunden-Karte', name: '24-Stunden-Karte', bereich: 'Berlin AB' },
  { pageName: 'Monatskarte (VBB Umweltkarte)', name: 'Monatskarte (VBB-Umweltkarte)', bereich: 'Berlin AB' },
];

let lastScrapeResult = { updatedCount: 0, skippedCount: 0, timestamp: null, details: [] };

function decodeHtmlEntities(text) {
  return text
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&uuml;/g, 'ü').replace(/&auml;/g, 'ä').replace(/&ouml;/g, 'ö')
    .replace(/&Uuml;/g, 'Ü').replace(/&Auml;/g, 'Ä').replace(/&Ouml;/g, 'Ö')
    .replace(/&szlig;/g, 'ß')
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(parseInt(code, 10)));
}

// Entfernt HTML-Tags zu reinem Text - bewusst simpel statt eines vollen
// HTML-Parsers, da wir nur nach Textmustern suchen und das robuster gegen
// Markup-Änderungen ist als CSS-Selektoren, die bei einem Redesign brechen.
function htmlToPlainText(html) {
  return decodeHtmlEntities(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, '\n'),
  ).replace(/\n{2,}/g, '\n');
}

/**
 * Sucht "ticketName" im Text und danach (innerhalb eines kurzen Fensters)
 * ein "Regeltarif [ab] X,XX €"-Muster. Gibt den Preis als Zahl zurück oder
 * null, wenn nichts Passendes gefunden wurde.
 */
function extractPrice(plainText, ticketName) {
  const idx = plainText.indexOf(ticketName);
  if (idx === -1) return null;

  const window = plainText.slice(idx, idx + ticketName.length + 400);
  const match = window.match(/Regeltarif\s+(?:ab\s+)?(\d+[.,]\d{2})\s*€/);
  if (!match) return null;

  const price = parseFloat(match[1].replace(',', '.'));
  if (Number.isNaN(price) || price < MIN_PLAUSIBLE_PRICE || price > MAX_PLAUSIBLE_PRICE) return null;

  return price;
}

function applyToFares(pageName, name, bereich, scrapedPrice) {
  for (const gruppe of FARES.gruppen) {
    const ticket = gruppe.tickets.find((t) => t.name === name && t.bereich === bereich);
    if (ticket) {
      const changed = ticket.preis !== scrapedPrice;
      ticket.preis = scrapedPrice;
      return changed;
    }
  }
  return false;
}

async function scrapeAndUpdate() {
  const response = await fetch(BVG_URL);
  if (!response.ok) throw new Error(`BVG-Seite antwortete mit Status ${response.status}`);
  const html = await response.text();
  const plainText = htmlToPlainText(html);

  let updatedCount = 0;
  let skippedCount = 0;
  const details = [];

  for (const target of SCRAPE_TARGETS) {
    const price = extractPrice(plainText, target.pageName);
    if (price == null) {
      skippedCount += 1;
      details.push({ ...target, status: 'nicht gefunden' });
      continue;
    }

    const changed = applyToFares(target.pageName, target.name, target.bereich, price);
    updatedCount += 1;
    details.push({ ...target, price, status: changed ? 'aktualisiert' : 'unverändert' });
  }

  FARES.stand = new Date().toISOString().slice(0, 10);
  lastScrapeResult = { updatedCount, skippedCount, timestamp: new Date().toISOString(), details };

  console.log(
    `[bvgPriceScraper] ${updatedCount} Preise geprüft/übernommen, ${skippedCount} nicht gefunden (Stand: ${lastScrapeResult.timestamp}).`,
  );
}

function initAndScheduleRefresh() {
  scrapeAndUpdate().catch((err) => console.warn('BVG-Preis-Scraping beim Start fehlgeschlagen, Tabelle bleibt beim zuletzt bekannten Stand:', err.message));

  setInterval(() => {
    scrapeAndUpdate().catch((err) => console.warn('Automatisches BVG-Preis-Scraping fehlgeschlagen:', err.message));
  }, REFRESH_INTERVAL_MS).unref();
}

function getStatus() {
  return lastScrapeResult;
}

module.exports = { initAndScheduleRefresh, getStatus, extractPrice, htmlToPlainText };
