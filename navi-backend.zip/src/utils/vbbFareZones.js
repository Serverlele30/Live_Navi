// Lädt den offiziellen VBB-Datensatz "vbb-alle-zielorte.csv", der jeder
// Station ihre Tarifzone zuordnet, und bietet darüber eine EXAKTE
// Zonen-Bestimmung für Berlin-Stadttarif-Stationen (statt der groben
// Entfernungs-Schätzung in fareEstimate.js).
//
// WICHTIG - Grenzen dieses Datensatzes:
// Nur Stationen mit eigenem Stadttarif (Berlin=B, Potsdam=P, Cottbus=CB,
// Frankfurt/Oder=FF, Brandenburg a.d.H.=BRB) haben ein klares "Stadt-Zone"-
// Feld (z.B. "B-A" = Berlin Zone A). Der Großteil der ländlichen
// Brandenburg-Stationen hat NUR eine Waben-Nummer (zone_id) - die exakte
// Tarifberechnung dafür folgt einem komplexen entfernungsbasierten
// Wabensystem, das wir hier NICHT abbilden. Für alles außerhalb von Berlins
// eigenem Stadttarif bleibt daher die Entfernungs-Schätzung in
// fareEstimate.js die einzige verfügbare Näherung.
//
// Datenquelle (von VBB offiziell für maschinenlesbare Nutzung freigegeben):
// https://www.vbb.de/fileadmin/user_upload/VBB/Dokumente/API-Datensaetze/vbb-alle-zielorte.csv

const fs = require('fs');
const path = require('path');

const CSV_URL = 'https://www.vbb.de/fileadmin/user_upload/VBB/Dokumente/API-Datensaetze/vbb-alle-zielorte.csv';
const CACHE_FILE = path.join(__dirname, '..', '..', 'data', 'vbb-fare-zones-cache.csv');
const REFRESH_INTERVAL_MS = 24 * 60 * 60 * 1000; // täglich neu laden

let berlinZoneByName = new Map(); // normalisierter Name -> 'A' | 'B' | 'C'
let lastUpdated = null;

function normalizeName(name) {
  if (!name) return null;
  let n = name;
  n = n.replace(/^(S\+U|U\+S|S|U|RE|RB|IC|ICE)\s+/i, ''); // Verkehrsmittel-Präfix
  n = n.replace(/\s*\(Berlin\)\s*$/i, '');
  n = n.replace(/\s*Bhf\.?\s*$/i, '');
  n = n.replace(/\s*Bahnhof\s*$/i, '');
  n = n.replace(/^Berlin[\s-]+/i, ''); // 'Berlin '/'Berlin-'-Präfix in der CSV
  n = n.replace(/[-,]/g, ' ');
  n = n.replace(/\s+/g, ' ').trim().toLowerCase();
  return n || null;
}

// Bei mehrdeutigen Einträgen wie "P-A/B-C" (Grenzgebiet zwischen zwei
// Stadttarifen) nehmen wir pragmatisch die erste genannte Zone.
function parseCityTarif(value) {
  if (!value) return null;
  const first = value.split('/')[0]; // z.B. "P-A/B-C" -> "P-A"
  const [city, zone] = first.split('-');
  if (!city || !zone) return null;
  return { city, zone };
}

function parseCsv(text) {
  const map = new Map();
  const lines = text.split(/\r?\n/);

  for (let i = 1; i < lines.length; i += 1) {
    const line = lines[i];
    if (!line.trim()) continue;
    const [stop, , cityTarif] = line.split(';');
    const parsed = parseCityTarif(cityTarif);
    if (!parsed || parsed.city !== 'B') continue; // nur Berlin ist für uns relevant

    const key = normalizeName(stop);
    if (key) map.set(key, parsed.zone);
  }

  return map;
}

async function fetchAndUpdate() {
  const response = await fetch(CSV_URL);
  if (!response.ok) throw new Error(`VBB-Server antwortete mit Status ${response.status}`);
  const text = await response.text();

  berlinZoneByName = parseCsv(text);
  lastUpdated = new Date();

  try {
    fs.mkdirSync(path.dirname(CACHE_FILE), { recursive: true });
    fs.writeFileSync(CACHE_FILE, text, 'utf-8');
  } catch (err) {
    console.warn('Konnte VBB-Tarifzonen-Cache nicht auf Disk schreiben:', err.message);
  }

  console.log(`[vbbFareZones] ${berlinZoneByName.size} Berlin-Stationen mit exakter Tarifzone geladen (Stand: ${lastUpdated.toISOString()}).`);
}

function loadFromDiskCache() {
  try {
    const text = fs.readFileSync(CACHE_FILE, 'utf-8');
    berlinZoneByName = parseCsv(text);
    lastUpdated = fs.statSync(CACHE_FILE).mtime;
    console.log(`[vbbFareZones] ${berlinZoneByName.size} Stationen aus Disk-Cache geladen (Stand: ${lastUpdated.toISOString()}).`);
    return true;
  } catch (err) {
    return false;
  }
}

// Beim Start: zuerst versuchen frisch von VBB zu laden, bei Fehler (z.B. kein
// Netz beim Start) auf den zuletzt gespeicherten Stand zurückfallen. Danach
// täglich im Hintergrund neu laden ("autonome Aktualisierung").
async function initAndScheduleRefresh() {
  try {
    await fetchAndUpdate();
  } catch (err) {
    console.warn('VBB-Tarifzonen konnten nicht frisch geladen werden, versuche Disk-Cache:', err.message);
    if (!loadFromDiskCache()) {
      console.warn('Kein Disk-Cache vorhanden - exakte Berlin-Tarifzonen sind bis zum nächsten erfolgreichen Abruf nicht verfügbar.');
    }
  }

  setInterval(() => {
    fetchAndUpdate().catch((err) => console.warn('Automatische Aktualisierung der VBB-Tarifzonen fehlgeschlagen:', err.message));
  }, REFRESH_INTERVAL_MS).unref();
}

function getBerlinZone(stationName) {
  const key = normalizeName(stationName);
  if (!key) return null;
  return berlinZoneByName.get(key) || null;
}

function getStatus() {
  return { stationsLoaded: berlinZoneByName.size, lastUpdated: lastUpdated ? lastUpdated.toISOString() : null };
}

module.exports = { initAndScheduleRefresh, getBerlinZone, getStatus, normalizeName, parseCsv };
