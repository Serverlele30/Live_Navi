// Client für die offizielle DB Timetables-API (IRIS), siehe
// https://developers.deutschebahn.com/db-api-marketplace/apis/product/timetables
//
// Wichtig: Diese API liefert XML, keine feste "Abfahrtstafel" wie HAFAS, sondern
// getrennt den Sollfahrplan (/plan) und die Änderungen (/fchg). Wir müssen beides
// selbst zusammenführen. Zeiten kommen im Format YYMMDDHHmm (10 Ziffern).
//
// Benötigt kostenlose Zugangsdaten (DB_IRIS_CLIENT_ID / DB_IRIS_API_KEY),
// Registrierung unter https://developers.deutschebahn.com

const { XMLParser } = require('fast-xml-parser');

const BASE_URL = 'https://apis.deutschebahn.com/db-api-marketplace/apis/timetables/v1';

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '',
  isArray: (name) => name === 's' || name === 'm',
});

function getCredentials() {
  const clientId = process.env.DB_IRIS_CLIENT_ID;
  const apiKey = process.env.DB_IRIS_API_KEY;
  if (!clientId || !apiKey) {
    const err = new Error('DB_IRIS_CLIENT_ID / DB_IRIS_API_KEY sind nicht konfiguriert.');
    err.code = 'MISSING_CREDENTIALS';
    throw err;
  }
  return { clientId, apiKey };
}

async function irisRequest(path) {
  const { clientId, apiKey } = getCredentials();

  const response = await fetch(`${BASE_URL}${path}`, {
    headers: {
      'DB-Client-Id': clientId,
      'DB-Api-Key': apiKey,
      Accept: 'application/xml',
    },
  });

  if (!response.ok) {
    const body = await response.text().catch(() => '');
    const err = new Error(`IRIS-API antwortete mit Status ${response.status}: ${body.slice(0, 200)}`);
    err.status = response.status;
    throw err;
  }

  const xml = await response.text();
  return parser.parse(xml);
}

// YYMMDDHHmm -> ISO-String (Europe/Berlin, ohne DST-Korrektur - IRIS liefert
// bereits lokale Zeit, wir bilden sie 1:1 auf ein Date ohne Zeitzonen-Shift ab)
function parseIrisTime(t) {
  if (!t || t.length !== 10) return null;
  const yy = parseInt(t.slice(0, 2), 10);
  const year = 2000 + yy;
  const month = parseInt(t.slice(2, 4), 10) - 1;
  const day = parseInt(t.slice(4, 6), 10);
  const hour = parseInt(t.slice(6, 8), 10);
  const minute = parseInt(t.slice(8, 10), 10);
  // Als "local time" Date konstruieren; new Date(y,m,d,h,min) nutzt die
  // Server-Zeitzone. Für die Anzeige (nur Uhrzeit) ist das ausreichend.
  return new Date(year, month, day, hour, minute).toISOString();
}

async function searchStations(pattern) {
  const data = await irisRequest(`/station/${encodeURIComponent(pattern)}`);
  const stations = data.stations && data.stations.station
    ? [].concat(data.stations.station)
    : [];
  return stations.map((s) => ({
    evaNumber: s.eva,
    name: s.name,
  }));
}

async function getPlan(evaNo, date, hour) {
  const data = await irisRequest(`/plan/${encodeURIComponent(evaNo)}/${date}/${hour}`);
  return normalizeTimetable(data);
}

async function getFullChanges(evaNo) {
  const data = await irisRequest(`/fchg/${encodeURIComponent(evaNo)}`);
  return normalizeTimetable(data);
}

async function getRecentChanges(evaNo) {
  const data = await irisRequest(`/rchg/${encodeURIComponent(evaNo)}`);
  return normalizeTimetable(data);
}

function normalizeTimetable(data) {
  if (!data.timetable) return { station: null, stops: [] };
  const stops = data.timetable.s ? [].concat(data.timetable.s) : [];
  return {
    station: data.timetable.station || null,
    stops,
  };
}

module.exports = {
  searchStations,
  getPlan,
  getFullChanges,
  getRecentChanges,
  parseIrisTime,
};
