const dbIris = require('./dbIris');
const { mergeStops } = require('./dbDepartureMerge');
const { withCache } = require('./cache');

function pad2(n) {
  return String(n).padStart(2, '0');
}

function upcomingHourSlices(count) {
  const slices = [];
  const now = new Date();
  for (let i = 0; i < count; i += 1) {
    const t = new Date(now.getTime() + i * 60 * 60 * 1000);
    const yy = pad2(t.getFullYear() % 100);
    const mm = pad2(t.getMonth() + 1);
    const dd = pad2(t.getDate());
    slices.push({ date: `${yy}${mm}${dd}`, hour: pad2(t.getHours()) });
  }
  return slices;
}

// Kernlogik für DB-IRIS-Abfahrten, ausgelagert aus routes/dbTimetables.js,
// damit sie sowohl von der normalen Route als auch vom kombinierten
// Favoriten-Sammel-Endpunkt (routes/summary.js) genutzt werden kann.
async function getDbDepartures(evaNo, { hours = 2, results = 20 } = {}) {
  const departures = await withCache(`db-departures:${evaNo}:${hours}`, 25_000, async () => {
    const slices = upcomingHourSlices(hours);
    const planResponses = await Promise.all(
      slices.map((s) => dbIris.getPlan(evaNo, s.date, s.hour)),
    );

    let changeStops = [];
    try {
      const changes = await dbIris.getFullChanges(evaNo);
      changeStops = changes.stops;
    } catch (changesErr) {
      console.warn(`Änderungen für ${evaNo} nicht abrufbar, zeige Sollfahrplan ohne Echtzeit-Update:`, changesErr.message);
    }

    const allPlanStops = planResponses.flatMap((r) => r.stops);
    if (allPlanStops.length === 0) {
      const notFound = new Error('NOT_FOUND');
      notFound.code = 'STATION_NOT_FOUND';
      throw notFound;
    }

    return mergeStops(allPlanStops, changeStops);
  });

  return departures.slice(0, results);
}

module.exports = { getDbDepartures };
