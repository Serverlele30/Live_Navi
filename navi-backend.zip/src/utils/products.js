// Baut das "products"-Filterobjekt für hafas-client aus einem Komma-getrennten
// Query-Parameter wie "modes=suburban,subway,bus".
// Gibt undefined zurück, wenn kein Filter gewünscht ist (= alle Verkehrsmittel, HAFAS-Standard).

const ALL_MODES = ['suburban', 'subway', 'tram', 'bus', 'ferry', 'express', 'regional'];

// Deutsche Labels, praktisch für Frontend-Doku/Fehlermeldungen.
const MODE_LABELS = {
  suburban: 'S-Bahn',
  subway: 'U-Bahn',
  tram: 'Tram',
  bus: 'Bus',
  ferry: 'Fähre',
  express: 'Fernverkehr (ICE/IC)',
  regional: 'Regionalbahn (RE/RB)',
};

function buildProductsFilter(modesParam) {
  if (!modesParam) return undefined;

  const allowed = modesParam
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

  const invalid = allowed.filter((m) => !ALL_MODES.includes(m));
  if (invalid.length > 0) {
    throw new Error(`Unbekannte Verkehrsmittel: ${invalid.join(', ')}. Erlaubt: ${ALL_MODES.join(', ')}`);
  }

  const products = {};
  ALL_MODES.forEach((mode) => {
    products[mode] = allowed.includes(mode);
  });
  return products;
}

module.exports = { buildProductsFilter, ALL_MODES, MODE_LABELS };
