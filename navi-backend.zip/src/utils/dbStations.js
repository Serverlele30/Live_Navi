// Lädt einmalig beim ersten Zugriff alle echten DB-Bahnhöfe (aus dem npm-Paket
// "db-stations", offline/lokal, CC BY 4.0) in den Speicher und bietet darüber
// eine schnelle, gewichtete Fuzzy-Suche an ("db-stations-autocomplete").
//
// WICHTIG: Wir nutzen bewusst "db-stations" (nur "echte" Bahnhöfe mit einer
// IBNR-Nummer, ca. 5.400 Stationen) und NICHT "db-hafas-stations" (alle
// ~290.000 Nahverkehrs-Haltestellen bundesweit inkl. U-Bahn/Tram/Bus-Halte).
// Grund: die IRIS-Timetables-API kennt NUR echte DB-Station&Service-Bahnhöfe.
// Mit dem größeren Datensatz fanden Nutzer z.B. "Alexanderplatz [U5]"
// (eine reine U-Bahn-Haltestelle) - die IRIS-API kennt diese ID aber gar
// nicht und die Abfahrtsabfrage schlägt fehl. Mit "db-stations" bekommt man
// zu "Alexanderplatz" nur den einen echten (S-)Bahnhof zurück.
//
// Warum nicht einfach die Live-Suche der IRIS-API (/station/{pattern})
// nutzen? Die ist bekanntermaßen schwach: bei generischen Suchbegriffen wie
// "Frankfurt" oder "München" liefert sie oft nur EINEN, unpassenden Treffer.

const { autocomplete } = require('db-stations-autocomplete');

let stationsByIdPromise = null;

async function loadStations() {
  const { readStations } = await import('db-stations');
  return new Promise((resolve, reject) => {
    const map = Object.create(null);
    readStations()
      .on('data', (s) => { map[s.id] = s; })
      .once('end', () => resolve(map))
      .once('error', reject);
  });
}

// Lazy: wird beim ersten Aufruf geladen und danach im Speicher gehalten.
// Serverstart kann optional vorab "warmStationsCache()" aufrufen, damit die
// erste echte Anfrage nicht auf das Einlesen warten muss.
function getStationsById() {
  if (!stationsByIdPromise) {
    stationsByIdPromise = loadStations();
  }
  return stationsByIdPromise;
}

function warmStationsCache() {
  getStationsById().catch((err) => {
    console.error('Konnte DB-Stationsliste nicht vorladen:', err);
  });
}

async function searchStations(query, limit = 8) {
  const stationsById = await getStationsById();
  const results = autocomplete(query, limit);

  return results
    .map((r) => {
      const station = stationsById[r.id];
      if (!station) return null;
      return { evaNumber: station.id, name: station.name, relevance: r.relevance };
    })
    .filter(Boolean);
}

module.exports = { searchStations, warmStationsCache };
