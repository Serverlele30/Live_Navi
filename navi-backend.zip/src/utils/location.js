// Baut den "from"/"to"-Parameter für hafas.journeys() aus Query-Parametern.
// Unterstützt Haltestellen-IDs, POIs und freie Koordinaten (Adresse/GPS-Standort).
//
// WICHTIG: POIs (Sehenswürdigkeiten, Hotels etc.) haben eine eigene ID in einem
// ANDEREN ID-Raum als Haltestellen. Eine POI-ID darf NIE als bloße Haltestellen-ID
// an hafas.journeys() übergeben werden - HAFAS würde dann erfolglos nach einer
// "Haltestelle" mit dieser ID suchen und einen LOCATION-Fehler werfen. Für POIs
// muss stattdessen das vollständige Location-Objekt mit "poi: true" gesendet werden.
//
// Erwartete Query-Parameter (Präfix ist z.B. "from" oder "to"):
//   fromId              -> Haltestellen-ID
//   fromPoiId           -> POI-ID (erfordert zusätzlich fromLat/fromLon/fromName)
//   fromLat / fromLon   -> Koordinaten (POI, Adresse oder GPS-Standort)
//   fromName            -> Anzeigename für POI/Koordinate (optional)
//   fromAddress         -> falls es sich um eine Adresse handelt (optional)

function buildLocationParam(query, prefix) {
  const id = query[`${prefix}Id`];
  if (id) return id;

  const lat = query[`${prefix}Lat`];
  const lon = query[`${prefix}Lon`];
  if (lat != null && lon != null) {
    const latitude = parseFloat(lat);
    const longitude = parseFloat(lon);
    if (Number.isNaN(latitude) || Number.isNaN(longitude)) return null;

    const poiId = query[`${prefix}PoiId`];
    const name = query[`${prefix}Name`];
    if (poiId) {
      return { type: 'location', id: poiId, poi: true, name: name || undefined, latitude, longitude };
    }

    const address = query[`${prefix}Address`];
    if (address) {
      return { type: 'location', address, latitude, longitude };
    }
    return { type: 'location', latitude, longitude, name: name || undefined };
  }

  return null;
}

module.exports = { buildLocationParam };
