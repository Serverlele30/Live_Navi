// Übersetzt technische HAFAS-Fehler (siehe hafas-client/lib/errors.js) in
// verständliche deutsche Meldungen, statt pauschal "Fehler beim Abfragen der
// VBB-API" zu zeigen. So weiß der Nutzer z.B. "Kein Reiseweg gefunden" statt
// eines nichtssagenden API-Fehlers.

const FRIENDLY_MESSAGES = {
  H891: 'Für diese Verbindung wurde kein Reiseweg gefunden. Versuch es mit einem Zwischenhalt oder einer anderen Uhrzeit.',
  H892: 'Die Anfrage ist zu komplex. Versuch es mit weniger Zwischenstopps oder einer direkteren Verbindung.',
  H895: 'Start und Ziel liegen zu nah beieinander für eine Routenberechnung.',
  H9220: 'In der Nähe dieser Adresse wurden keine Haltestellen gefunden.',
  H9260: 'Die Start-Haltestelle ist unbekannt.',
  H9280: 'Eine Zwischenstation ist unbekannt.',
  H9300: 'Die Ziel-Haltestelle ist unbekannt.',
  H9320: 'Die Eingabe ist unvollständig oder ungültig.',
  H9360: 'Das angegebene Datum bzw. die Uhrzeit ist ungültig.',
  H9380: 'Start, Ziel oder Zwischenstopp wurden mehrfach angegeben.',
  H9240: 'Für diese Verbindung konnten keine Ergebnisse gefunden werden.',
  H890: 'Für diese Verbindung konnten keine Ergebnisse gefunden werden.',
  LOCATION: 'Die angegebene Haltestelle oder Adresse wurde nicht gefunden.',
  NO_MATCH: 'Keine Ergebnisse gefunden.',
  PARAMETER: 'Ungültige Anfrage-Parameter.',
  R0002: 'Ungültige oder fehlende Parameter in der Anfrage.',
  SQ005: 'Für diese Fahrt wurden keine Daten gefunden.',
  TI001: 'Für diese Fahrt sind aktuell keine Live-Informationen verfügbar.',
};

// Fallback-Meldungen nach grober Fehlerkategorie, falls der genaue Code
// (noch) nicht in der Liste oben steht.
const FALLBACK_BY_CODE = {
  ACCESS_DENIED: 'Zugriff auf die VBB-Daten wurde verweigert.',
  INVALID_REQUEST: 'Die Anfrage enthält ungültige Angaben. Bitte Eingaben prüfen.',
  NOT_FOUND: 'Dazu wurden keine Ergebnisse gefunden.',
  SERVER_ERROR: 'Die VBB-Datenquelle hat gerade ein Problem. Bitte gleich nochmal versuchen.',
};

// HTTP-Status passend zur Fehlerkategorie (statt immer pauschal 502).
const STATUS_BY_CODE = {
  ACCESS_DENIED: 502,
  INVALID_REQUEST: 400,
  NOT_FOUND: 404,
  SERVER_ERROR: 502,
};

/**
 * Nimmt einen (möglicherweise HAFAS-) Error entgegen und gibt
 * { status, message } für die HTTP-Antwort zurück.
 */
function friendlyHafasError(err, fallbackMessage) {
  if (err && err.isHafasError) {
    const hafasCode = err.hafasCode;
    const message = (hafasCode && FRIENDLY_MESSAGES[hafasCode]) || FALLBACK_BY_CODE[err.code] || fallbackMessage;
    const status = STATUS_BY_CODE[err.code] || 502;
    return { status, message };
  }
  return { status: 502, message: fallbackMessage };
}

module.exports = { friendlyHafasError };
