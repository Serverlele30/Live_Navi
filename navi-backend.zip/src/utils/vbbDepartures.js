const hafas = require('./hafas');
const { buildProductsFilter } = require('./products');
const { getLineColor } = require('./lineColors');
const { withCache } = require('./cache');

// Kernlogik für VBB-Abfahrten, ausgelagert aus routes/departures.js, damit sie
// sowohl von der normalen Abfahrten-Route als auch vom kombinierten
// Favoriten-Sammel-Endpunkt (routes/summary.js) genutzt werden kann.
async function getVbbDepartures(stationId, { duration = 30, results = 20, modes } = {}) {
  const products = buildProductsFilter(modes);
  const cacheKey = `vbb-departures:${stationId}:${duration}:${results}:${modes || ''}`;

  const { departures } = await withCache(cacheKey, 20_000, () =>
    hafas.departures(stationId, {
      duration,
      results,
      remarks: true,
      ...(products ? { products } : {}),
    }),
  );

  return departures.map((dep) => {
    const { bg, fg } = getLineColor(dep.line ? dep.line.product : null, dep.line ? dep.line.name : null);
    return {
      tripId: dep.tripId,
      line: dep.line ? dep.line.name : null,
      mode: dep.line ? dep.line.product : null,
      color: bg,
      textColor: fg,
      direction: dep.direction,
      plannedWhen: dep.plannedWhen,
      when: dep.when,
      delay: dep.delay,
      platform: dep.platform,
      plannedPlatform: dep.plannedPlatform,
      cancelled: !!dep.cancelled,
      remarks: dep.remarks || [],
    };
  });
}

module.exports = { getVbbDepartures };
