// Dekodiert das "Encoded Polyline"-Format (Google-Algorithmus), das OTP2 für
// die Geometrie von Verbindungsabschnitten liefert. Wandelt es in dasselbe
// GeoJSON-FeatureCollection-Format um, das wir schon von hafas-client kennen,
// damit die Karten-Zeichnung im Frontend unverändert weiterfunktioniert.

function decodePolyline(encoded) {
  if (!encoded) return [];

  const points = [];
  let index = 0;
  let lat = 0;
  let lon = 0;

  while (index < encoded.length) {
    let shift = 0;
    let result = 0;
    let byte;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    const deltaLat = result & 1 ? ~(result >> 1) : result >> 1;
    lat += deltaLat;

    shift = 0;
    result = 0;
    do {
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    const deltaLon = result & 1 ? ~(result >> 1) : result >> 1;
    lon += deltaLon;

    points.push([lat / 1e5, lon / 1e5]); // [latitude, longitude]
  }

  return points;
}

// Baut aus dekodierten Punkten dieselbe GeoJSON-FeatureCollection-Struktur,
// die unser Frontend bereits von den VBB-/hafas-client-Polylines kennt.
function polylineToGeoJson(encoded) {
  const points = decodePolyline(encoded);
  return {
    type: 'FeatureCollection',
    features: points.map(([lat, lon]) => ({
      type: 'Feature',
      properties: {},
      geometry: { type: 'Point', coordinates: [lon, lat] },
    })),
  };
}

module.exports = { decodePolyline, polylineToGeoJson };
