// Führt die getrennten IRIS-Antworten (Sollfahrplan aus /plan, Änderungen aus
// /fchg) zu einer einzigen Abfahrtsliste zusammen - im GLEICHEN Format wie
// unsere VBB-/departures-Route, damit das Frontend beide Quellen mit demselben
// Code darstellen kann.

const { parseIrisTime } = require('./dbIris');

function buildLineName(tl) {
  if (!tl) return null;
  const category = tl.c || '';
  const number = tl.n || '';
  return [category, number].filter(Boolean).join(' ') || null;
}

// Grobe Farbgebung nach Verkehrsart, da es für die Vielzahl an privaten
// Regionalbahn-Betreibern (HLB, VIA, vlexx, ...) keine offizielle Farbtabelle
// wie bei VBB gibt. Nutzt das von IRIS selbst gesetzte "f"-Flag (Fernverkehr/
// Nahverkehr/S-Bahn) statt brüchigem Text-Parsing der Kategorie.
function getDbLineColor(tl) {
  if (!tl) return { bg: '#8E99A6', fg: '#fff' };
  if (tl.f === 'F') return { bg: '#EC0016', fg: '#fff' }; // Fernverkehr: DB-Rot
  if (tl.c === 'S') return { bg: '#006F35', fg: '#fff' }; // S-Bahn: Grün
  return { bg: '#003090', fg: '#fff' }; // Regionalverkehr (RE/RB/private Betreiber): Blau
}

function mergeStops(planStops, changeStops) {
  const changesById = new Map();
  changeStops.forEach((s) => {
    if (s.id) changesById.set(s.id, s);
  });

  const departures = [];

  planStops.forEach((s) => {
    const dp = s.dp;
    if (!dp) return; // reiner Ankunfts-Halt (Zugende) - für eine Abfahrtstafel nicht relevant

    const change = changesById.get(s.id);
    const dpChange = change && change.dp ? change.dp : null;

    const plannedWhen = parseIrisTime(dp.pt);
    const changedWhen = dpChange && dpChange.ct ? parseIrisTime(dpChange.ct) : null;
    const when = changedWhen || plannedWhen;

    const delay = plannedWhen && changedWhen
      ? Math.round((new Date(changedWhen) - new Date(plannedWhen)) / 1000)
      : 0;

    const cancelled = !!(dpChange && dpChange.cs === 'c');
    const plannedPlatform = dp.pp || null;
    const platform = (dpChange && dpChange.cp) || plannedPlatform;

    const path = dp.ppth ? dp.ppth.split('|') : [];
    const direction = path.length ? path[path.length - 1] : null;
    const { bg, fg } = getDbLineColor(s.tl);

    departures.push({
      tripId: s.id,
      line: buildLineName(s.tl),
      mode: s.tl ? s.tl.c : null,
      color: bg,
      textColor: fg,
      direction,
      plannedWhen,
      when,
      delay,
      platform,
      plannedPlatform,
      cancelled,
      remarks: [],
    });
  });

  departures.sort((a, b) => new Date(a.when) - new Date(b.when));
  return departures;
}

module.exports = { mergeStops };
