// Zentraler HAFAS-Client für den VBB-Verbund.
// Wird von allen Routen gemeinsam genutzt, damit nicht überall neu instanziiert wird.

const { createClient } = require('hafas-client');
const { profile: vbbProfile } = require('hafas-client/p/vbb');

const userAgent = process.env.HAFAS_USER_AGENT || 'oepnv-navi-app';

const hafas = createClient(vbbProfile, userAgent);

module.exports = hafas;
