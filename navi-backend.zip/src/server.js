require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const locationsRouter = require('./routes/locations');
const departuresRouter = require('./routes/departures');
const journeysRouter = require('./routes/journeys');
const radarRouter = require('./routes/radar');
const favoritesRouter = require('./routes/favorites');
const pushRouter = require('./routes/push');
const tripRouter = require('./routes/trip');
const remarksRouter = require('./routes/remarks');
const faresRouter = require('./routes/fares');
const disruptionsRouter = require('./routes/disruptions');
const dbTimetablesRouter = require('./routes/dbTimetables');
const otpJourneysRouter = require('./routes/otpJourneys');
const healthRouter = require('./routes/health');
const summaryRouter = require('./routes/summary');
const { warmStationsCache } = require('./utils/dbStations');
const vbbFareZones = require('./utils/vbbFareZones');
const bvgPriceScraper = require('./utils/bvgPriceScraper');

const app = express();
const PORT = process.env.PORT || 3000;

// Wichtig hinter einem Reverse Proxy (NPM), damit Rate-Limiting & Logging die echte
// Client-IP aus dem X-Forwarded-For Header lesen statt die des Proxys.
app.set('trust proxy', 1);

app.use(helmet());
app.use(
  cors({
    origin: process.env.CORS_ORIGIN === '*' ? '*' : (process.env.CORS_ORIGIN || '*').split(','),
  }),
);
app.use(express.json());
app.use(morgan('combined'));

// Globales Rate-Limit, da das Backend öffentlich im Internet erreichbar ist.
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 Minute
  limit: 60, // max. 60 Anfragen pro Minute pro IP
  standardHeaders: true,
  legacyHeaders: false,
});
app.use(limiter);

// Basis-Pfad, unter dem NPM den Traffic weiterleitet (siehe README für NPM-Konfiguration).
// NPM leitet bei "Custom Locations" standardmäßig die komplette URL inkl. Präfix weiter,
// deshalb mountet das Backend seine Routen selbst unter diesem Präfix.
const BASE_PATH = process.env.BASE_PATH || '/live_navi';
const router = express.Router();

// Health-Check (z.B. für Uptime-Monitoring oder NPM-Healthcheck)
router.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

router.use('/locations', locationsRouter);
router.use('/stations', locationsRouter); // Alias für Rückwärtskompatibilität mit der alten Website
router.use('/departures', departuresRouter);
router.use('/journeys', journeysRouter);
router.use('/radar', radarRouter);
router.use('/favorites', favoritesRouter);
router.use('/push', pushRouter);
router.use('/trip', tripRouter);
router.use('/remarks', remarksRouter);
router.use('/fares', faresRouter);
router.use('/disruptions', disruptionsRouter);
router.use('/db', dbTimetablesRouter);
router.use('/otp/journeys', otpJourneysRouter);
router.use('/health', healthRouter);
router.use('/summary', summaryRouter);

app.use(BASE_PATH, router);

// Zusätzlicher Health-Check auf Root-Ebene, praktisch für direkte lokale Checks
// (z.B. "curl http://<lan-ip>:3000/health"), unabhängig vom NPM-Präfix.
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpunkt nicht gefunden.' });
});

// Zentraler Error-Handler
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('Unerwarteter Fehler:', err);
  res.status(500).json({ error: 'Interner Serverfehler.' });
});

app.listen(PORT, () => {
  console.log(`ÖPNV Navi Backend läuft auf Port ${PORT}`);
  warmStationsCache(); // lädt die ~5.400 DB-Bahnhofsnamen im Hintergrund vor
  vbbFareZones.initAndScheduleRefresh(); // lädt VBB-Tarifzonen, danach täglich automatisch neu
  bvgPriceScraper.initAndScheduleRefresh(); // holt aktuelle Preise von bvg.de, danach täglich automatisch neu
});
