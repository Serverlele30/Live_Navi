const express = require('express');
const hafas = require('../utils/hafas');
const { getLineColor } = require('../utils/lineColors');
const { friendlyHafasError } = require('../utils/hafasErrors');

const router = express.Router();

// GET /trip/:id?polyline=true
// Details zu einer einzelnen Fahrt (z.B. aus journey.legs[].tripId oder einer
// Abfahrt), inklusive aktueller Live-Position und komplettem Streckenverlauf
// mit allen Zwischenhalten. Nützlich für die Trip-Detailansicht in der App
// und um eine Verbindung "live mitzuverfolgen" wie bei Google Maps.
router.get('/:id', async (req, res) => {
  const wantPolyline = req.query.polyline === 'true';

  try {
    const { trip } = await hafas.trip(decodeURIComponent(req.params.id), {
      stopovers: true,
      polyline: wantPolyline,
      remarks: true,
    });

    const { bg, fg } = getLineColor(trip.line ? trip.line.product : null, trip.line ? trip.line.name : null);

    res.json({
      id: trip.id,
      direction: trip.direction,
      line: trip.line ? trip.line.name : null,
      mode: trip.line ? trip.line.product : null,
      color: bg,
      textColor: fg,
      currentLocation: trip.currentLocation || null,
      origin: trip.origin ? trip.origin.name : null,
      destination: trip.destination ? trip.destination.name : null,
      departure: trip.departure,
      plannedDeparture: trip.plannedDeparture,
      departureDelay: trip.departureDelay,
      arrival: trip.arrival,
      plannedArrival: trip.plannedArrival,
      arrivalDelay: trip.arrivalDelay,
      cancelled: !!trip.cancelled,
      remarks: trip.remarks || [],
      stopovers: (trip.stopovers || []).map((s) => ({
        name: s.stop ? s.stop.name : null,
        arrival: s.arrival,
        plannedArrival: s.plannedArrival,
        arrivalDelay: s.arrivalDelay,
        departure: s.departure,
        plannedDeparture: s.plannedDeparture,
        departureDelay: s.departureDelay,
        cancelled: !!s.cancelled,
      })),
      polyline: wantPolyline ? trip.polyline || null : undefined,
    });
  } catch (err) {
    console.error('Fehler bei /trip/:id:', err);
    const { status, message } = friendlyHafasError(err, 'Fehler beim Abfragen der VBB-API.');
    res.status(status).json({ error: message });
  }
});

module.exports = router;
