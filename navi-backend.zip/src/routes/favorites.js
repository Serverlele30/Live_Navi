const express = require('express');
const db = require('../db/database');
const requireApiKey = require('../middleware/apiKey');

const router = express.Router();

// GET /favorites
// Liste aller gespeicherten Lieblings-Haltestellen.
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT id, station_id, station_name, label, created_at FROM favorites ORDER BY created_at DESC').all();
  res.json({ favorites: rows });
});

// POST /favorites   (benötigt X-API-Key Header)
// body: { "stationId": "900000100003", "stationName": "S+U Alexanderplatz", "label": "Zuhause" }
router.post('/', requireApiKey, (req, res) => {
  const { stationId, stationName, label } = req.body || {};

  if (!stationId || !stationName) {
    return res.status(400).json({ error: '"stationId" und "stationName" sind erforderlich.' });
  }

  const stmt = db.prepare('INSERT INTO favorites (station_id, station_name, label) VALUES (?, ?, ?)');
  const result = stmt.run(stationId, stationName, label || null);

  res.status(201).json({ id: result.lastInsertRowid, stationId, stationName, label: label || null });
});

// DELETE /favorites/:id   (benötigt X-API-Key Header)
router.delete('/:id', requireApiKey, (req, res) => {
  const result = db.prepare('DELETE FROM favorites WHERE id = ?').run(req.params.id);

  if (result.changes === 0) {
    return res.status(404).json({ error: 'Favorit nicht gefunden.' });
  }

  res.status(204).send();
});

module.exports = router;
