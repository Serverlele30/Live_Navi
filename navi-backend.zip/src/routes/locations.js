const express = require('express');
const hafas = require('../utils/hafas');

const router = express.Router();

function formatLocation(loc) {
  const base = {
    id: loc.id || null,
    name: loc.name || loc.address || null,
    latitude: loc.location ? loc.location.latitude : loc.latitude || null,
    longitude: loc.location ? loc.location.longitude : loc.longitude || null,
  };

  if (loc.type === 'stop' || loc.type === 'station') {
    return { ...base, kind: 'stop', products: loc.products || null };
  }
  if (loc.poi) {
    return { ...base, kind: 'poi' };
  }
  if (loc.address) {
    return { ...base, kind: 'address', name: loc.address };
  }
  return { ...base, kind: loc.type || 'unknown' };
}

// GET /locations/search?query=Alexanderplatz
// Sucht Haltestellen, Adressen UND Sehenswürdigkeiten/POIs - für einen
// Routenplaner, der wie Google Maps auch "von zu Hause" statt nur
// "von Haltestelle X" versteht.
router.get('/search', async (req, res) => {
  const query = req.query.query;

  if (!query || query.trim().length < 2) {
    return res.status(400).json({ error: 'Parameter "query" fehlt oder ist zu kurz (min. 2 Zeichen).' });
  }

  try {
    const results = await hafas.locations(query, {
      results: 12,
      stops: true,
      addresses: true,
      poi: true,
    });

    res.json({ locations: results.map(formatLocation) });
  } catch (err) {
    console.error('Fehler bei /locations/search:', err);
    res.status(502).json({ error: 'Fehler beim Abfragen der VBB-API.' });
  }
});

// GET /locations/nearby?lat=52.51&lon=13.40&distance=500&results=10
// Haltestellen (und optional POIs) in der Nähe einer Koordinate - z.B. dem
// aktuellen GPS-Standort des Nutzers ("Haltestellen in meiner Nähe").
router.get('/nearby', async (req, res) => {
  const { lat, lon, distance, results, includePoi } = req.query;

  const latitude = parseFloat(lat);
  const longitude = parseFloat(lon);

  if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
    return res.status(400).json({ error: 'Parameter "lat" und "lon" sind erforderlich und müssen Zahlen sein.' });
  }

  try {
    const nearby = await hafas.nearby(
      { type: 'location', latitude, longitude },
      {
        results: parseInt(results, 10) || 10,
        distance: distance ? parseInt(distance, 10) : undefined,
        stops: true,
        poi: includePoi === 'true',
      },
    );

    res.json({
      locations: nearby.map((loc) => ({ ...formatLocation(loc), distance: loc.distance ?? null })),
    });
  } catch (err) {
    console.error('Fehler bei /locations/nearby:', err);
    res.status(502).json({ error: 'Fehler beim Abfragen der VBB-API.' });
  }
});

// GET /locations/:id
// Details zu einer einzelnen Haltestelle.
router.get('/:id', async (req, res) => {
  try {
    const stop = await hafas.stop(req.params.id);
    res.json(formatLocation(stop));
  } catch (err) {
    console.error('Fehler bei /locations/:id:', err);
    res.status(502).json({ error: 'Fehler beim Abfragen der VBB-API.' });
  }
});

module.exports = router;
