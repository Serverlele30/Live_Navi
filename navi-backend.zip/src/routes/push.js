const express = require('express');
const db = require('../db/database');
const requireApiKey = require('../middleware/apiKey');

const router = express.Router();

// POST /push/register   (benötigt X-API-Key Header)
// body: { "deviceToken": "<APNs Token>", "platform": "ios" }
// Speichert den Geräte-Token, damit die App später z.B. bei Verspätungen benachrichtigt werden kann.
router.post('/register', requireApiKey, (req, res) => {
  const { deviceToken, platform } = req.body || {};

  if (!deviceToken) {
    return res.status(400).json({ error: '"deviceToken" ist erforderlich.' });
  }

  const stmt = db.prepare(`
    INSERT INTO push_tokens (device_token, platform)
    VALUES (?, ?)
    ON CONFLICT(device_token) DO UPDATE SET platform = excluded.platform
  `);
  stmt.run(deviceToken, platform || 'ios');

  res.status(201).json({ status: 'registriert' });
});

module.exports = router;
