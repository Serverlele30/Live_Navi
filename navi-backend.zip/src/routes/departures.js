const express = require('express');
const { getVbbDepartures } = require('../utils/vbbDepartures');
const { friendlyHafasError } = require('../utils/hafasErrors');

const router = express.Router();

// GET /departures/:stationId?duration=30&results=20&modes=suburban,subway,bus
// Liefert die nächsten Abfahrten (mit Verspätungen) für eine Haltestelle.
// "modes" filtert optional nach Verkehrsmitteln (Komma-Liste), siehe utils/products.js.
router.get('/:stationId', async (req, res) => {
  const { stationId } = req.params;
  const duration = parseInt(req.query.duration, 10) || 30;
  const results = parseInt(req.query.results, 10) || 20;

  try {
    const departures = await getVbbDepartures(stationId, { duration, results, modes: req.query.modes });
    res.json({ stationId, departures });
  } catch (err) {
    console.error('Fehler bei /departures/:stationId:', err);
    const { status, message } = friendlyHafasError(err, 'Fehler beim Abfragen der VBB-API.');
    res.status(status).json({ error: message });
  }
});

module.exports = router;
