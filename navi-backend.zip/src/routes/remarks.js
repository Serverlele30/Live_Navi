const express = require('express');
const hafas = require('../utils/hafas');
const { buildProductsFilter } = require('../utils/products');

const router = express.Router();

// GET /remarks?modes=suburban,subway&results=50
// Netzweite Störungsmeldungen und Bauarbeiten-Hinweise, unabhängig von einer
// bestimmten Haltestelle - für eine "Verkehrslage"-Übersicht wie bei Google Maps.
router.get('/', async (req, res) => {
  let products;
  try {
    products = buildProductsFilter(req.query.modes);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  const results = parseInt(req.query.results, 10) || 50;

  try {
    const { remarks } = await hafas.remarks({
      results,
      ...(products ? { products } : {}),
    });

    const formatted = remarks.map((r) => ({
      id: r.id,
      type: r.type,
      summary: r.summary,
      text: r.text,
      company: r.company || null,
      validFrom: r.validFrom || null,
      validUntil: r.validUntil || null,
    }));

    res.json({ remarks: formatted });
  } catch (err) {
    console.error('Fehler bei /remarks:', err);
    res.status(502).json({ error: 'Fehler beim Abfragen der VBB-API.' });
  }
});

module.exports = router;
