const express = require('express');
const hafas = require('../utils/hafas');
const dbIris = require('../utils/dbIris');
const vbbFareZones = require('../utils/vbbFareZones');
const bvgPriceScraper = require('../utils/bvgPriceScraper');

const router = express.Router();

async function timed(fn) {
  const start = Date.now();
  try {
    await fn();
    return { ok: true, latencyMs: Date.now() - start };
  } catch (err) {
    return { ok: false, latencyMs: Date.now() - start, error: err.message };
  }
}

async function checkVbb() {
  return timed(() => hafas.locations('Berlin Hauptbahnhof', { results: 1 }));
}

async function checkDbIris() {
  return timed(async () => {
    const now = new Date();
    const yy = String(now.getFullYear() % 100).padStart(2, '0');
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const hh = String(now.getHours()).padStart(2, '0');
    // Frankfurt Hbf (8000105) als bekannter, stabiler Test-Bahnhof.
    await dbIris.getPlan('8000105', `${yy}${mm}${dd}`, hh);
  });
}

async function checkOtp() {
  const OTP_BASE_URL = process.env.OTP_BASE_URL || 'http://localhost:8080/otp/gtfs/v1';
  return timed(async () => {
    const response = await fetch(OTP_BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: '{ __typename }' }),
    });
    if (!response.ok) throw new Error(`Status ${response.status}`);
    const body = await response.json();
    if (body.errors) throw new Error(body.errors.map((e) => e.message).join('; '));
  });
}

async function checkAll() {
  const dbIrisConfigured = !!(process.env.DB_IRIS_CLIENT_ID && process.env.DB_IRIS_API_KEY);

  const [vbb, dbIrisResult, otp] = await Promise.all([
    checkVbb(),
    dbIrisConfigured ? checkDbIris() : Promise.resolve({ ok: false, error: 'Zugangsdaten nicht konfiguriert' }),
    checkOtp(),
  ]);

  const sources = {
    vbb: { ...vbb, label: 'VBB (Berlin/Brandenburg)' },
    dbIris: { ...dbIrisResult, label: 'DB-IRIS (bundesweit)' },
    otp: { ...otp, label: 'OTP2 (Routenplanung VBB)' },
    fareZones: (() => {
      const status = vbbFareZones.getStatus();
      return {
        ok: status.stationsLoaded > 0,
        label: 'VBB-Tarifzonen (exakte Preise)',
        error: status.stationsLoaded > 0 ? undefined : 'Noch nicht geladen',
        latencyMs: null,
        detail: status.lastUpdated ? `${status.stationsLoaded} Stationen, Stand: ${new Date(status.lastUpdated).toLocaleString('de-DE')}` : null,
      };
    })(),
    bvgPrices: (() => {
      const status = bvgPriceScraper.getStatus();
      return {
        ok: status.timestamp != null && status.updatedCount > 0,
        label: 'BVG-Ticketpreise (automatisch aktualisiert)',
        error: status.timestamp ? undefined : 'Noch nicht geladen',
        latencyMs: null,
        detail: status.timestamp
          ? `${status.updatedCount} Preise geprüft, Stand: ${new Date(status.timestamp).toLocaleString('de-DE')}`
          : null,
      };
    })(),
  };

  const allOk = Object.values(sources).every((s) => s.ok);
  return { status: allOk ? 'ok' : 'degraded', timestamp: new Date().toISOString(), sources, allOk };
}

// GET /health/full
// JSON-Variante für Skripte/curl/Monitoring-Tools.
router.get('/full', async (req, res) => {
  const result = await checkAll();
  res.status(result.allOk ? 200 : 207).json({
    status: result.status,
    timestamp: result.timestamp,
    sources: result.sources,
  });
});

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
}

function renderDashboardHtml(result) {
  const rows = Object.values(result.sources)
    .map((s) => {
      const statusClass = s.ok ? 'ok' : 'down';
      const statusText = s.ok ? '✅ Erreichbar' : '❌ Nicht erreichbar';
      const latency = s.latencyMs != null ? `${s.latencyMs} ms` : '–';
      const errorRow = s.error ? `<div class="error">${escapeHtml(s.error)}</div>` : '';
      const detailRow = s.detail ? `<div class="latency">${escapeHtml(s.detail)}</div>` : '';
      const latencyRow = s.latencyMs != null ? `<div class="latency">Antwortzeit: ${latency}</div>` : '';
      return `
        <div class="card ${statusClass}">
          <div class="card-header">
            <span class="dot"></span>
            <strong>${escapeHtml(s.label)}</strong>
          </div>
          <div class="status">${statusText}</div>
          ${latencyRow}
          ${detailRow}
          ${errorRow}
        </div>
      `;
    })
    .join('');

  return `<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="refresh" content="30" />
<title>ÖPNV Navi – Status</title>
<style>
  :root { color-scheme: dark; }
  body { margin: 0; background: #0C1116; color: #E6E9ED; font-family: -apple-system, "IBM Plex Sans", sans-serif; padding: 24px 16px; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .meta { color: #8E99A6; font-size: 13px; margin-bottom: 20px; }
  .overall { display: inline-block; padding: 4px 12px; border-radius: 999px; font-size: 13px; font-weight: 600; margin-bottom: 20px; }
  .overall.ok { background: rgba(0,200,120,0.15); color: #00C878; }
  .overall.degraded { background: rgba(255,93,108,0.15); color: #FF5D6C; }
  .grid { display: flex; flex-direction: column; gap: 12px; max-width: 480px; }
  .card { background: #151B22; border: 1px solid #232B34; border-radius: 12px; padding: 14px 16px; }
  .card.down { border-color: #FF5D6C; }
  .card-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
  .dot { width: 10px; height: 10px; border-radius: 50%; background: #00C878; flex-shrink: 0; }
  .card.down .dot { background: #FF5D6C; }
  .status { font-size: 14px; margin-bottom: 2px; }
  .latency { font-size: 12px; color: #8E99A6; }
  .error { margin-top: 6px; font-size: 12px; color: #FF5D6C; background: rgba(255,93,108,0.1); padding: 6px 8px; border-radius: 6px; }
  .refresh-note { margin-top: 20px; font-size: 12px; color: #8E99A6; }
</style>
</head>
<body>
  <h1>ÖPNV Navi – Systemstatus</h1>
  <div class="meta">Stand: ${escapeHtml(new Date(result.timestamp).toLocaleString('de-DE'))}</div>
  <div class="overall ${result.allOk ? 'ok' : 'degraded'}">${result.allOk ? 'Alle Systeme funktionsfähig' : 'Eingeschränkte Funktionalität'}</div>
  <div class="grid">${rows}</div>
  <div class="refresh-note">Aktualisiert sich automatisch alle 30 Sekunden</div>
</body>
</html>`;
}

// GET /health/dashboard
// Sichtbare HTML-Statusseite (statt nur rohem JSON) - zum Draufschauen im Browser.
router.get('/dashboard', async (req, res) => {
  const result = await checkAll();
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(renderDashboardHtml(result));
});

module.exports = router;
