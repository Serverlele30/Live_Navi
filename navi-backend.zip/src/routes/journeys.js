const express = require('express');
const hafas = require('../utils/hafas');
const { buildProductsFilter } = require('../utils/products');
const { buildLocationParam } = require('../utils/location');
const { getLineColor } = require('../utils/lineColors');
const { friendlyHafasError } = require('../utils/hafasErrors');
const { estimateFare } = require('../utils/fareEstimate');

const router = express.Router();

// GET /journeys
// Query-Parameter:
//   from / to            -> Haltestellen-ID (Legacy, weiterhin unterstützt)
//   fromId / toId         -> Haltestellen-ID (bevorzugt)
//   fromLat/fromLon(+fromName|fromAddress), analog für "to"
//                          -> freie Koordinate (Adresse, POI, GPS-Standort)
//   when                  -> ISO-Datum/Zeit (Standard: jetzt)
//   arrival=true           -> "when" als Ankunftszeit statt Abfahrtszeit interpretieren
//   modes                 -> Komma-Liste erlaubter Verkehrsmittel (siehe utils/products.js)
//   polylines=true         -> Liniengeometrie pro Streckenabschnitt mitliefern (für die Karte)
//   results                -> Anzahl Verbindungen (Standard 5)
router.get('/', async (req, res) => {
  const from = buildLocationParam(req.query, 'from') || req.query.from;
  const to = buildLocationParam(req.query, 'to') || req.query.to;

  if (!from || !to) {
    return res.status(400).json({
      error: 'Start und Ziel sind erforderlich (fromId/toId, oder fromLat+fromLon/toLat+toLon, oder das Legacy-Feld from/to).',
    });
  }

  let products;
  try {
    products = buildProductsFilter(req.query.modes);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  const arrival = req.query.arrival === 'true';
  const when = req.query.when ? new Date(req.query.when) : new Date();
  const polylines = req.query.polylines === 'true';
  const results = parseInt(req.query.results, 10) || 5;
  const accessibility = req.query.accessibility === 'true' ? 'complete' : 'none';
  const bike = req.query.bike === 'true';

  try {
    const { journeys } = await hafas.journeys(from, to, {
      results,
      stopovers: false,
      polylines,
      accessibility,
      bike,
      ...(arrival ? { arrival: when } : { departure: when }),
      ...(products ? { products } : {}),
    });

    const formatted = journeys.map((journey) => {
      const legs = journey.legs.map((leg) => {
        const { bg, fg } = leg.walking
          ? { bg: '#8E99A6', fg: '#fff' }
          : getLineColor(leg.line ? leg.line.product : null, leg.line ? leg.line.name : null);
        return {
          tripId: leg.tripId || null,
          line: leg.line ? leg.line.name : null,
          mode: leg.line ? leg.line.product : null,
          color: bg,
          textColor: fg,
          origin: leg.origin ? leg.origin.name : null,
          destination: leg.destination ? leg.destination.name : null,
          originLat: leg.origin ? leg.origin.latitude : null,
          originLon: leg.origin ? leg.origin.longitude : null,
          destinationLat: leg.destination ? leg.destination.latitude : null,
          destinationLon: leg.destination ? leg.destination.longitude : null,
          departure: leg.departure,
          arrival: leg.arrival,
          delay: leg.departureDelay,
          walking: !!leg.walking,
          distance: leg.distance || null, // Meter, nur bei Fußwegen gesetzt
          polyline: polylines ? leg.polyline || null : undefined,
        };
      });

      const first = legs[0];
      const last = legs[legs.length - 1];
      const fareEstimate = first && last
        ? estimateFare(first.originLat, first.originLon, last.destinationLat, last.destinationLon)
        : null;

      return { legs, fareEstimate };
    });

    res.json({ journeys: formatted });
  } catch (err) {
    console.error('Fehler bei /journeys:', err);
    const { status, message } = friendlyHafasError(err, 'Fehler beim Abfragen der VBB-API.');
    res.status(status).json({ error: message });
  }
});

module.exports = router;
