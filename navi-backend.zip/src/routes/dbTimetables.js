const express = require('express');
const dbStations = require('../utils/dbStations');
const { getDbDepartures } = require('../utils/dbDeparturesService');

const router = express.Router();

function handleIrisError(err, res) {
  console.error('Fehler bei DB-IRIS-Anfrage:', err);
  if (err.code === 'MISSING_CREDENTIALS') {
    return res.status(503).json({
      error: 'Die bundesweite DB-Anbindung ist auf diesem Server noch nicht eingerichtet (fehlende API-Zugangsdaten).',
    });
  }
  return res.status(502).json({ error: 'Fehler beim Abfragen der DB-Timetables-API.' });
}

router.get('/stations/search', async (req, res) => {
  const query = req.query.query;
  if (!query || query.trim().length < 2) {
    return res.status(400).json({ error: 'Parameter "query" fehlt oder ist zu kurz (min. 2 Zeichen).' });
  }

  try {
    const stations = await dbStations.searchStations(query.trim(), 8);
    res.json({ stations });
  } catch (err) {
    console.error('Fehler bei der lokalen DB-Stationssuche:', err);
    res.status(502).json({ error: 'Fehler bei der Stationssuche.' });
  }
});

router.get('/departures/:evaNo', async (req, res) => {
  const { evaNo } = req.params;
  const hours = Math.min(parseInt(req.query.hours, 10) || 2, 4);
  const results = parseInt(req.query.results, 10) || 20;

  try {
    const departures = await getDbDepartures(evaNo, { hours, results });
    res.json({ stationId: evaNo, departures, source: 'db-iris' });
  } catch (err) {
    if (err.code === 'STATION_NOT_FOUND') {
      return res.status(404).json({
        error: 'Für diese Station wurden keine Abfahrten gefunden. Ist die EVA-Nummer korrekt?',
      });
    }
    handleIrisError(err, res);
  }
});

module.exports = router;
