const express = require('express');
const { FARES } = require('../data/fares');

const router = express.Router();

// GET /fares
// Statische Fahrpreis-Referenzdaten (keine HAFAS-Live-Daten - Preise gibt es
// über die VBB-API nicht). Immer mit "ohne Gewähr" im Frontend anzeigen.
router.get('/', (req, res) => {
  res.json(FARES);
});

module.exports = router;
