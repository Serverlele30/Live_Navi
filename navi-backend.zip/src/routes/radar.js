const express = require('express');
const hafas = require('../utils/hafas');
const { getLineColor } = require('../utils/lineColors');
const { buildProductsFilter } = require('../utils/products');
const { friendlyHafasError } = require('../utils/hafasErrors');

const router = express.Router();

// Ermittelt den tatsächlich nächsten Halt eines Fahrzeugs. "frames[0].destination"
// beschreibt eindeutig, wohin sich das Fahrzeug GERADE bewegt (aktuelles Segment
// der Fahrt) - das ist zuverlässiger als "nextStopovers[0]", welches je nach
// Echtzeit-Stand auch schon den aktuellen/gerade verlassenen Halt zeigen kann,
// wenn das Fahrzeug z.B. gerade an einer Haltestelle steht.
function getNextStopoverName(m) {
  if (m.frames && m.frames[0] && m.frames[0].destination) {
    return m.frames[0].destination.name;
  }
  if (m.nextStopovers && m.nextStopovers[0] && m.nextStopovers[0].stop) {
    return m.nextStopovers[0].stop.name;
  }
  return null;
}

// GET /radar?north=52.55&west=13.35&south=52.48&east=13.47&modes=subway,tram&tripId=...
// Liefert aktuelle Fahrzeugpositionen innerhalb eines Kartenausschnitts (für die Live-Map).
// "modes" filtert nach Verkehrsmitteln, "tripId" isoliert ein einzelnes Fahrzeug
// (z.B. nachdem der Nutzer auf eine Linie geklickt hat - alle anderen werden ausgeblendet,
// während dieses eine live weiterverfolgt wird).
router.get('/', async (req, res) => {
  const { north, west, south, east, tripId } = req.query;

  if (!north || !west || !south || !east) {
    return res.status(400).json({
      error: 'Parameter "north", "west", "south" und "east" (Koordinaten des Kartenausschnitts) sind erforderlich.',
    });
  }

  let products;
  try {
    products = buildProductsFilter(req.query.modes);
  } catch (err) {
    return res.status(400).json({ error: err.message });
  }

  try {
    const { movements } = await hafas.radar(
      {
        north: parseFloat(north),
        west: parseFloat(west),
        south: parseFloat(south),
        east: parseFloat(east),
      },
      {
        results: 256,
        ...(products ? { products } : {}),
        ...(tripId ? { tripId: decodeURIComponent(tripId) } : {}),
      },
    );

    const formatted = movements.map((m) => {
      const { bg, fg } = getLineColor(m.line ? m.line.product : null, m.line ? m.line.name : null);
      return {
        tripId: m.tripId || m.trip,
        line: m.line ? m.line.name : null,
        mode: m.line ? m.line.product : null,
        color: bg,
        textColor: fg,
        direction: m.direction,
        latitude: m.location ? m.location.latitude : null,
        longitude: m.location ? m.location.longitude : null,
        nextStopover: getNextStopoverName(m),
      };
    });

    res.json({ vehicles: formatted });
  } catch (err) {
    console.error('Fehler bei /radar:', err);
    const { status, message } = friendlyHafasError(err, 'Fehler beim Abfragen der VBB-API.');
    res.status(status).json({ error: message });
  }
});

module.exports = router;
