const express = require('express');
const { planJourney } = require('../utils/otpClient');
const { getLineColorByNameOnly } = require('../utils/lineColors');
const { polylineToGeoJson } = require('../utils/decodePolyline');
const { estimateFareExact } = require('../utils/fareEstimate');
const { withCache } = require('../utils/cache');

const router = express.Router();

const WALK_COLOR = { bg: '#8E99A6', fg: '#fff' };

function pickTime(endpoint, field) {
  // field ist "departure" (für from) oder "arrival" (für to). Nutzt die
  // Echtzeit-Schätzung, falls vorhanden, sonst den Sollfahrplan.
  const info = endpoint && endpoint[field];
  if (!info) return null;
  if (info.estimated && info.estimated.time) return info.estimated.time;
  return info.scheduledTime || null;
}

function pickDelay(endpoint, field) {
  const info = endpoint && endpoint[field];
  if (!info || !info.estimated) return 0;
  return info.estimated.delay || 0;
}

// GET /otp/journeys?fromLat=&fromLon=&toLat=&toLon=&when=&arrival=true&polylines=true&results=5
// Routenplaner auf Basis unserer selbst gehosteten OpenTripPlanner-2-Instanz
// (VBB-GTFS + OpenStreetMap Berlin/Brandenburg) - komplett offen, ohne
// Abhängigkeit von HAFAS. Nur Koordinaten als Ein-/Ausgabe, keine Haltestellen-
// IDs (die OTP-eigenen GTFS-Stop-IDs sind ohnehin nicht mit VBB-HAFAS-IDs
// kompatibel - Koordinaten sind der kleinste gemeinsame Nenner).
router.get('/', async (req, res) => {
  const fromLat = parseFloat(req.query.fromLat);
  const fromLon = parseFloat(req.query.fromLon);
  const toLat = parseFloat(req.query.toLat);
  const toLon = parseFloat(req.query.toLon);

  if ([fromLat, fromLon, toLat, toLon].some((v) => Number.isNaN(v))) {
    return res.status(400).json({
      error: 'Start und Ziel sind erforderlich (fromLat, fromLon, toLat, toLon).',
    });
  }

  const arriveBy = req.query.arrival === 'true';
  const wantPolylines = req.query.polylines === 'true';
  const numItineraries = Math.min(parseInt(req.query.results, 10) || 5, 10);

  try {
    const cacheKey = `otp-journeys:${fromLat}:${fromLon}:${toLat}:${toLon}:${req.query.when || 'now'}:${arriveBy}:${numItineraries}`;
    const itineraries = await withCache(cacheKey, 30_000, () =>
      planJourney({
        fromLat,
        fromLon,
        toLat,
        toLon,
        dateTime: req.query.when || undefined,
        arriveBy,
        numItineraries,
      }),
    );

    const journeys = itineraries.map((itinerary) => {
      const legs = itinerary.legs.map((leg) => {
        const walking = leg.mode === 'WALK';
        const lineName = leg.route ? leg.route.shortName : null;
        const { bg, fg } = walking ? WALK_COLOR : getLineColorByNameOnly(lineName);

        return {
          tripId: null, // OTP liefert hier keine mit anderen Quellen vergleichbare Trip-ID
          line: lineName,
          mode: leg.mode,
          color: bg,
          textColor: fg,
          origin: leg.from ? leg.from.name : null,
          destination: leg.to ? leg.to.name : null,
          originLat: leg.from ? leg.from.lat : null,
          originLon: leg.from ? leg.from.lon : null,
          destinationLat: leg.to ? leg.to.lat : null,
          destinationLon: leg.to ? leg.to.lon : null,
          departure: pickTime(leg.from, 'departure'),
          arrival: pickTime(leg.to, 'arrival'),
          delay: pickDelay(leg.from, 'departure'),
          walking,
          distance: walking ? Math.round(leg.distance) : null,
          polyline: wantPolylines && leg.legGeometry ? polylineToGeoJson(leg.legGeometry.points) : undefined,
        };
      });

      const first = legs[0];
      const last = legs[legs.length - 1];
      const fareEstimate = first && last
        ? estimateFareExact(first.origin, last.destination, first.originLat, first.originLon, last.destinationLat, last.destinationLon)
        : null;

      return { legs, fareEstimate };
    });

    res.json({ journeys });
  } catch (err) {
    console.error('Fehler bei /otp/journeys:', err);
    if (err.code === 'OTP_UNREACHABLE') {
      return res.status(503).json({ error: 'Der Routenplaner-Server ist gerade nicht erreichbar.' });
    }
    if (err.code === 'OTP_GRAPHQL_ERROR') {
      // Zeigt die echte Fehlermeldung von OTP an (z.B. Schema-/Query-Probleme),
      // statt sie hinter einer nichtssagenden generischen Meldung zu verstecken.
      return res.status(502).json({ error: err.message });
    }
    res.status(502).json({ error: 'Fehler beim Abfragen des Routenplaners.' });
  }
});

module.exports = router;
