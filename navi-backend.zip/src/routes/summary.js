const express = require('express');
const { getVbbDepartures } = require('../utils/vbbDepartures');
const { getDbDepartures } = require('../utils/dbDeparturesService');

const router = express.Router();

// POST /summary/departures
// body: { "stations": [{ "id": "900100003", "source": "vbb", "name": "..." }, ...] }
//
// Liefert für mehrere Haltestellen gleichzeitig jeweils die nächste Abfahrt -
// praktisch für eine Favoriten-Übersicht auf der Startseite oder ein
// Home-Widget, statt dafür N einzelne Anfragen zu stellen. Nutzt intern
// denselben Cache wie die normalen Abfahrten-Routen, kostet also nichts extra,
// wenn eine Station kurz zuvor schon einzeln abgefragt wurde.
router.post('/departures', async (req, res) => {
  const stations = req.body && req.body.stations;

  if (!Array.isArray(stations) || stations.length === 0) {
    return res.status(400).json({ error: '"stations" muss ein nicht-leeres Array aus { id, source } sein.' });
  }
  if (stations.length > 20) {
    return res.status(400).json({ error: 'Maximal 20 Stationen pro Anfrage.' });
  }

  const results = await Promise.all(
    stations.map(async (station) => {
      const { id, source, name } = station || {};
      if (!id || (source !== 'vbb' && source !== 'db')) {
        return { id, source, name, nextDeparture: null, error: 'Ungültige Station (benötigt "id" und "source": "vbb"|"db").' };
      }

      try {
        const departures = source === 'db'
          ? await getDbDepartures(id, { hours: 2, results: 1 })
          : await getVbbDepartures(id, { duration: 60, results: 1 });

        return { id, source, name, nextDeparture: departures[0] || null, error: null };
      } catch (err) {
        return { id, source, name, nextDeparture: null, error: err.message || 'Unbekannter Fehler' };
      }
    }),
  );

  res.json({ results });
});

module.exports = router;
