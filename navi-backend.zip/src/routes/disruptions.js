const express = require('express');
const hafas = require('../utils/hafas');
const { friendlyHafasError } = require('../utils/hafasErrors');

const router = express.Router();

const NOISE_CODES = new Set(['OPERATOR', 'FK']);

function isRealDisruption(remark) {
  if (NOISE_CODES.has(remark.code)) return false;
  if (remark.code && remark.code.startsWith('text.occup')) return false;
  return remark.type === 'warning' || remark.type === 'status';
}

// GET /disruptions/nearby?lat=&lon=&distance=800&stops=6
// Sucht Haltestellen in der Nähe einer Koordinate und sammelt aus deren aktuellen
// Abfahrten echte Störungsmeldungen. Anders als /remarks (netzweit) ist das
// wirklich ortsbezogen, weil es auf den tatsächlich hier verkehrenden Linien basiert.
router.get('/nearby', async (req, res) => {
  const { lat, lon, distance, stops } = req.query;
  const latitude = parseFloat(lat);
  const longitude = parseFloat(lon);

  if (Number.isNaN(latitude) || Number.isNaN(longitude)) {
    return res.status(400).json({ error: 'Parameter "lat" und "lon" sind erforderlich und müssen Zahlen sein.' });
  }

  const stopLimit = Math.min(parseInt(stops, 10) || 6, 10);

  try {
    const nearbyStops = await hafas.nearby(
      { type: 'location', latitude, longitude },
      { results: stopLimit, distance: distance ? parseInt(distance, 10) : 1000, stops: true, poi: false },
    );

    const results = await Promise.allSettled(
      nearbyStops
        .filter((s) => s.id)
        .map((s) => hafas.departures(s.id, { duration: 60, results: 20, remarks: true })),
    );

    const disruptionsByKey = new Map();

    results.forEach((result, i) => {
      if (result.status !== 'fulfilled') return;
      const stopName = nearbyStops[i].name;
      const departures = result.value.departures || [];

      departures.forEach((dep) => {
        (dep.remarks || []).filter(isRealDisruption).forEach((remark) => {
          const key = remark.id || `${remark.type}-${remark.text}`;
          if (!disruptionsByKey.has(key)) {
            disruptionsByKey.set(key, {
              id: remark.id || null,
              type: remark.type,
              summary: remark.summary || null,
              text: remark.text || null,
              affectedStops: new Set(),
              affectedLines: new Set(),
            });
          }
          const entry = disruptionsByKey.get(key);
          entry.affectedStops.add(stopName);
          if (dep.line && dep.line.name) entry.affectedLines.add(dep.line.name);
        });
      });
    });

    const disruptions = [...disruptionsByKey.values()].map((d) => ({
      id: d.id,
      type: d.type,
      summary: d.summary,
      text: d.text,
      affectedStops: [...d.affectedStops],
      affectedLines: [...d.affectedLines],
    }));

    res.json({ disruptions });
  } catch (err) {
    console.error('Fehler bei /disruptions/nearby:', err);
    const { status, message } = friendlyHafasError(err, 'Fehler beim Abfragen der VBB-API.');
    res.status(status).json({ error: message });
  }
});

module.exports = router;
